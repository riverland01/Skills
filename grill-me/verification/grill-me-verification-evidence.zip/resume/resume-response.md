We’ll continue from mentoring as your priority, with no career choice required today.

**What did you do with the junior colleague that made that day meaningful—and is that something you would want to do regularly?**
