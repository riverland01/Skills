Paused. I’ve saved the corrections in the decision record:

- The hiring manager reportedly confirmed **zero protected research time**; the earlier 40% assumption is superseded.
- **Mentoring matters more to you than personally doing deep analysis.** The good day mattered because a junior colleague learned from it.
- The role comparison is open again, and **no choice has been made**.

Next time we’ll start here: what meaningful mentoring looks like for you, and how much of it each role actually offers.
