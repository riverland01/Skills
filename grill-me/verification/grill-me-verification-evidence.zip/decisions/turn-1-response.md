I’ll keep the decision record in [grill-scientist-leadership.md](<${WORKSPACE}/work/validation/decisions/grill-scientist-leadership.md>).

Think of one recent workday that energized you and one that drained you. What were you doing on each, and what made the difference?

